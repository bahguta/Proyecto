
 
 * Este Proyecto ha sido desarollado para la asignatura "Proyecto" del instituto
 * "IES Juan Jose Calvo Miguel" - Sotrondio<br>
 * Tutor individual: Julia Paz Triana Toribio
 *
 * El programa se concentra en el manejo de la contabilidad de PYMES. Notas del Libro diario que se van
 * tomando, el stock de los productos que entran (compra) y salen (Venta) de la
 * empresa, las personas sean clientes o provedoores y manejo de facturas.
 * 
 * El programa ofrece personalizar la interfaz del programa
 * Se pueden cambiar los colores de la vista y el tamaño del texto.
