
	
	
insert into nota (fecha, detalle, debe, haber) values ( '2013/07/22', 'nota tomada en 2013', 1.44, 72.00);
insert into nota (fecha, detalle, debe, haber) values ('2009/07/17','nota tomada en 2009', 67.41, 88.88);
insert into nota (fecha, detalle, debe, haber) values ('2009/07/02','nota tomada en 2009', 166.44, 22.76);
insert into nota ( fecha, detalle, debe, haber) values ('2018/09/27','otra nota tomada en 2018', 12.74, 54.88);
insert into nota ( fecha, detalle, debe, haber) values ('2014/11/04','nota tomada en 2014, trabajo realizado ', 344.64, 222.88);
insert into nota ( fecha, detalle, debe, haber) values ('2016/03/09','nota tomada en 2016, servicios prestados', 12.88, 123.44);
insert into nota ( fecha, detalle, debe, haber) values ('2013/06/06','nota tomada en 2013', 455.74, 666.22);
insert into nota ( fecha, detalle, debe, haber) values ('2011/09/04','nota tomada en 2011, trabajo realizado ', 12.74, 54.44);
insert into nota ( fecha, detalle, debe, haber) values ('2016/03/23','nota tomada en 2016, servicios prestados', 23.00, 54.88);
insert into nota ( fecha, detalle, debe, haber) values ('2009/09/21','otra nota tomada en 2009', 1122.74, 344.44);
insert into nota ( fecha, detalle, debe, haber) values ('2006/09/22','nota tomada en 2006, trabajo realizado ', 12.74, 323.00);
insert into nota ( fecha, detalle, debe, haber) values ('2007/05/11','nota tomada en 2007, servicios prestados', 342.43, 54.00);
insert into nota ( fecha, detalle, debe, haber) values ('2014/09/27','otra nota tomada en 2014', 12.64, 342.44);
insert into nota ( fecha, detalle, debe, haber) values ('2018/01/16','nota tomada en 2018, trabajo realizado ', 665.74, 54.88);
insert into nota ( fecha, detalle, debe, haber) values ('2017/02/12','otra nota tomada en 2017, servicios prestados', 65.62, 555.88);
insert into nota ( fecha, detalle, debe, haber) values ('2018/09/18','nota tomada en 2018, trabajo realizado ', 12.74, 566.22);
insert into nota ( fecha, detalle, debe, haber) values ('2017/03/11','nota tomada en 2017, servicios prestados', 1233.22, 54.44);
insert into nota ( fecha, detalle, debe, haber) values ('2017/09/15','nota tomada en 2014, trabajo realizado ', 332.44, 54.66);
insert into nota ( fecha, detalle, debe, haber) values ('2018/06/23','nota tomada en 2014', 1112.74, 524.22);



  
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ('Juan','Gonzalez', 'avd Principal 1', 633656656, 'bahguta.pp@gmail.com', 'CLIENTE');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ('Rufo','de Vega', 'avd Principal 1', 455445345, 'sdfsd@gmail.com', 'CLIENTE');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ('Jesus','de Vazques', 'avd Cristo de las Cadenas 1', 654645654, 'dfgdfg.pp@gmail.com', 'CLIENTE');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ( 'Jose','Manuel', 'avd Llano 1', 343453454, 'jhkjhkljkl.pp@gmail.com', 'CLIENTE');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ( 'Felix','Prieto', 'avd Ramon y Cajal 1', 657788667, 'dfgd5435.pp@gmail.com', 'CLIENTE');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ( 'Javier','Fradejas', 'avd Principal 10', 653453455, 'fgjhgjgk3.pp@gmail.com', 'PROVEEDOR');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ( 'Plamen','Georgiev Petkov', 'avd Principal 1', 633656656, 'bahguta.pp@gmail.com', 'PROVEEDOR');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ('Montserrat','Diaz de Vega', 'avd Principal 1', 655445345, 'sdfsd@gmail.com', 'PROVEEDOR');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ( 'Juan','Fernandez', 'avd Cristo de las Cadenas 1', 654645654, 'dfgdfg.pp@gmail.com', 'PROVEEDOR');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ( 'Jose Manuel','Prieto', 'avd Llano 1', 643453454, 'jhkjhkljkl.pp@gmail.com', 'PROVEEDOR');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ( 'Virginia','Sanchez', 'avd Ramon y Cajal 1', 657788667, 'dfgd5435.pp@gmail.com', 'PROVEEDOR');
insert into persona ( nombre, apellido, direccion, telefono, email, type) values ('Legolas','Topalov', 'avd Principal 10', 453453453, 'fgjhgjgk3.pp@gmail.com', 'PROVEEDOR');


insert into producto (nombre, peso, precio, cantidad) values ('fsdfs', 56, 44, 60);
insert into producto (nombre, peso, precio, cantidad) values ('ssdfsdf', 765, 234, 50);
insert into producto (nombre, peso, precio, cantidad) values ('sdfsdf', 221, 54, 100);
insert into producto (nombre, peso, precio, cantidad) values ('sdfsdf', 66, 12, 5);
insert into producto (nombre, peso, precio, cantidad) values ('sdfdsf', 112, 43, 10);
insert into producto (nombre, peso, precio, cantidad) values ('sdfdsf', 234, 44, 21);
