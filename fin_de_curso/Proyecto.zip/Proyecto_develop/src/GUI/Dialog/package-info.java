/**
 *  <font color="#1E86C9">Paquete <b>GUI.Dialog</b></font>
 * <font color="#128555">
 * <br>Este paquete contiene los dialogos necesarios para llevar a cabo<br> las operaciones
 * como añadir facturas, personas productos y notas del libro diario</font>
 * 
 */
package GUI.Dialog;
