
/**
 * <font color="#1E86C9">
 * Paquete <b>GUI.MainBody</b></font>
 * <font color="#128555">
 * <br>El paquete <b>GUI.MainBody</b> representa la vista del modelo MVC.<br>
 * Contiene todos los paneles del programa</font>
 * 
 */

package GUI.MainBody;
