/**
 * <font color="#1E86C9">
 * Paquete <b>GUI.Main</b></font>
 * <font color="#128555">
 * <br>Este Proyecto ha sido <em>desarollado</em> para la asignatura "Proyecto" <br>del instituto
 * "IES Juan Jose Calvo Miguel" - Sotrondio<br><br>
 * Tutor individual: Julia Paz Triana Toribio<br>
 * Tutor colectivo: Jose Luis Arias Cobrero<br><br>
 *
 * El programa se concentra en el manejo de la contabilidad de PYMES.<br>Notas del Libro diario que se van
 * tomando, el stock de los productos que entran (compra) y salen (Venta)<br> de la
 * empresa, las personas sean clientes o provedoores y manejo de facturas.<br><br>
 * 
 * El programa ofrece personalizar la interfaz del programa <br>
 * Se pueden cambiar los colores de la vista y el tamaño del texto.</font>
 */
package GUI.Main;
