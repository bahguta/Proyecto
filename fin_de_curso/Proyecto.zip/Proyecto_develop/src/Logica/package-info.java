
/**
 * <font color="#1E86C9">
 * Paquete <b>Logica</b></font>
 * <font color="#128555">
 * <br>El paquete <b>Logica</b> representa lo que se conoce como el controlador del modelo MVC.
 * <br>Contiene toda la logica del programa.</font>
 * 
 */

package Logica;
