
/**
 * <font color="#1E86C9">
 * Paquete <b>img</b></font>
 * <font color="#128555">
 * <br>El paquete <b>img</b> contiene todas las imagenes del programa</font>
 * 
 */

package img;
