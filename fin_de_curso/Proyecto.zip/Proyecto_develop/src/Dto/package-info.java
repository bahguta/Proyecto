
/**
 * <font color="#1E86C9">
 * Paquete <b>Dto</b></font>
 * <font color="#128555">
 * <br>Este paquete contiene los modelos de los objetos necesarios<br>para la implementacion de MVC</font>
 * 
 */

package Dto;
