
/**
 * <font color="#1E86C9">
 * Paquete <b>Gestiones</b></font>
 * <font color="#128555">
 * <br>Este paquete hace la conexion con el modelo , obtiene todos los datos que se piden del controlador.<br>
 * Hace la comunicacion con la base de datos. </font>
 * 
 */

package Gestiones;
